#ifndef Morse_h
#define Morse_h
#include "Arduino.h"

class Morse{
	public: 
		Morse(int pin);
		void dot();
		void dash();
		void letras(char letra);
	private:
		int _pin;
		char _letra;



};

#endif